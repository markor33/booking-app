export class Address {
    country: string = '';
    city: string = '';
    street: string = '';
    number: string = '';
}
