import { Address } from "./address";

export class User {
    firstName: string = '';
    lastName: string = '';
    address: Address = new Address();
}
