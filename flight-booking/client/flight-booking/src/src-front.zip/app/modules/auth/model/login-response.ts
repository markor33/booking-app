export interface LoginResponse {
    jwt: string;
}
