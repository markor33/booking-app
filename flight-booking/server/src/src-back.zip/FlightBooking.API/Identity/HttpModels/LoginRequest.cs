﻿namespace FlightBooking.API.Identity.HttpModels
{
    public class LoginRequest
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
