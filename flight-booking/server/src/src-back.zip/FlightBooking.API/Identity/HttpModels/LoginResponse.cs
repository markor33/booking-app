﻿namespace FlightBooking.API.Identity.HttpModels
{
    public class LoginResponse
    {
        public string Jwt { get; set; }
    }
}
